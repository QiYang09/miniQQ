package com.example.qq;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class QQ extends AppCompatActivity {
    private final String ACCOUNT = "20219415";
    private final String PASSWORD = "zznbzznb";
    private EditText accountEdit;
    private EditText passwordEdit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qq);
        setButton1();
    }
    private void setButton1(){
        Button button1 = (Button)findViewById(R.id.button_1);
        accountEdit = findViewById(R.id.edit_t1);
        passwordEdit = findViewById(R.id.edit_t2);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String account = accountEdit.getText().toString();
                String password = passwordEdit.getText().toString();
                if (account.equals(ACCOUNT) && password.equals(PASSWORD)) {
                    startActivity(new Intent(QQ.this, zz.class));
                } else {
                    Toast.makeText(QQ.this,"账号或密码错误", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
